<form action="sbmt.php" method="post">
<input type="text" name="name" id="ee">
<input type="submit" value = "set date">

</form>
<?php
echo $_POST["name"];
?>
