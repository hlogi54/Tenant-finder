var myBtn = document.querySelector('.modal-btn');
var modalBg = document.querySelector('.modal-bg');

myBtn.addEventListener('click',function(){
    modalBg.classList.add("bg-active");
});
